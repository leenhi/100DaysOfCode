

<!-- Magnific-popup css -->
<link rel="stylesheet" type="text/css" href="http://dimsemenov-static.s3.amazonaws.com/dist/magnific-popup.css">

<!-- J-query library -->

<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>

<!-- Magnific-popup core javascript -->

<script type="text/javascript" src="http://dimsemenov-static.s3.amazonaws.com/dist/jquery.magnific-popup.min.js" >
</script>


<!-- magnific-popup initializer pop up code -->
<script type="text/javascript"  src="js/index.js"  ></script>