# SIMPLY-Lightbox-Gallery
In this project we show how to make a lightbox effect on your picture gallery using the magnific pop -up plugin. The webpage is set up using html and css then styled and finally the plug-in is used.
